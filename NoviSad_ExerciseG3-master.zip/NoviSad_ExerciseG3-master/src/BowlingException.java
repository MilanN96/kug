
public class BowlingException extends Exception {

	public BowlingException() {
		super();
	}

	public BowlingException(String message) {
		super(message);
	}

}
